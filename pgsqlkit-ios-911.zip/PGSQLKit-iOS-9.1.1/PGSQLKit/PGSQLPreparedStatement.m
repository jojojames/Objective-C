//
//  PGSQLPreparedStatement.m
//  PGSQLKit
//
//  Created by Andy Satori on 1/30/09.
//  Copyright 2009 Druware Software Designs. All rights reserved.
//

#import "PGSQLPreparedStatement.h"


@implementation PGSQLPreparedStatement



/*PGresult *PQprepare(PGconn *conn,
 const char *stmtName,
 const char *query,
 int nParams,
 const Oid *paramTypes);
 */

@end
